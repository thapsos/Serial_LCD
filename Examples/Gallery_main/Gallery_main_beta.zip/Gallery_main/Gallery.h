// 
// μLCD-32PT(SGC) 3.2” Serial LCD Display Module
// Arduino & chipKIT Library
// ----------------------------------
// Developped with embedXcode
//
// Feb 16, 2012 release 108
// see README.txt
//
// © Rei VILO, 2010-2012
// CC = BY NC SA
// http://sites.google.com/site/vilorei/
// http://github.com/rei-vilo/Serial_LCD
//
//
// Based on
// 4D LABS PICASO-SGC Command Set
// Software Interface Specification
// Document Date: 1st March 2011 
// Document Revision: 6.0
// http://www.4d-Labs.com
//
//
#define GALLERY_RELEASE 101

#include "WProgram.h"
#include "Serial_LCD.h"
#include "vector.h"

// Test release
#if SERIAL_LCD_RELEASE < 120
#error required SERIAL_LCD_RELEASE 120
#endif


#ifndef Gallery_h
#define Gallery_h





class Gallery {
public:
  Gallery(); // constructor
  ~Gallery(); // destructor
  uint8_t begin(Serial_LCD * lcd0, String name);
  uint8_t number();
  uint8_t index();
  uint8_t showNext();
  uint8_t showPrevious();
  uint8_t showImage(uint8_t i);

private:
  struct image_t {
    //    String name;
    uint16_t msb, lsb, x, y;
  };

  Serial_LCD * _pscreen;
  String _name;
  uint8_t _index;
  Vector <image_t> _gallery;
};


#endif



//void setup() {
//  Serial.begin(19200);
//  Serial.print("\n\n\n***\n");
//
//  Serial.print(sizeof(s)/sizeof(s[0]), DEC);
//  Serial.print("\n");
//
//  String a = "\"moins.jpg\" ABCD abcd 1234 04";
//
//
//  //  splitString(a, ' ', s, 5);
//  splitString(a, ' ', s, 5);
//
//  Serial.print(a);
//  Serial.print("\n");
//
//
//  for (uint8_t i=0; i<5; i++) {
//    Serial.print("[");
//    Serial.print(i, DEC);
//    Serial.print("]=");
//    Serial.print(s[i]);
//    Serial.print(".\t");
//        Serial.print(stoh(s[i]), HEX);
//    Serial.print(".\t");
//        Serial.print(stod(s[i]), HEX);
//    Serial.print(".\n");
//  }
//
//  while(1) { 
//    delay(100); 
//  }
//}
//
//
//void loop() {
//
//}
//
//
//




