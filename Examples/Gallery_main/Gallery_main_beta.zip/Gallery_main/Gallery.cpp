// 
// μLCD-32PT(SGC) 3.2” Serial LCD Display Module
// Arduino & chipKIT Library
// ----------------------------------
// Developped with embedXcode
//
// Feb 16, 2012 release 108
// see README.txt
//
// © Rei VILO, 2010-2012
// CC = BY NC SA
// http://sites.google.com/site/vilorei/
// http://github.com/rei-vilo/Serial_LCD
//
//
// Based on
// 4D LABS PICASO-SGC Command Set
// Software Interface Specification
// Document Date: 1st March 2011 
// Document Revision: 6.0
// http://www.4d-Labs.com
//
//

#include "WProgram.h"
#include "Serial_LCD.h"
#include "Gallery.h"
#include "vector.h"

//Gallery myGallery;





uint16_t stoh(String in) {
  char c;
  uint16_t w = 0;
  in = in.trim();

  for (uint8_t i=0; i<in.length(); i++) {
    c = in.charAt(i);
    w <<= 4; 
    if ((c>='0') && (c<='9')) w |= (c-'0');
    else if ((c>='A') && (c<='F')) w |= (c-'A'+0x0a);
    else if ((c>='a') && (c<='f')) w |= (c-'a'+0x0a);
    else;
  }
  return w;
}

uint16_t stod(String in) {
  char c;
  uint16_t w = 0;
  in = in.trim();

  for (uint8_t i=0; i<in.length(); i++) {
    c = in.charAt(i);
    w *= 10; 
    if ((c>='0') && (c<='9')) w |= (c-'0');
    else;
  }
  return w;
}


uint8_t splitString(String in, char delimiter, String s[], uint8_t max) {
  uint8_t j=0;
  char c;
  s[0]='\0';

  for (uint8_t i=0; i<in.length(); i++) {
    c = in.charAt(i);
    if ( c=='\0' ) return j;

    else if ( c==delimiter ) {
      j++;
      if (j+1>max) return j; 
      s[j]='\0';
    } 
    else s[j] += c;
  }
} 


Gallery::Gallery() { // constructor
}

Gallery::~Gallery() { // destructor
}

uint8_t Gallery::begin(Serial_LCD * lcd0, String name) {
  uint8_t a;
  _pscreen = lcd0;
  String text;
  String s[5];
  _name = name;

  a = _pscreen->findFile(_name + ".gci");
  if (a==0x15) return 0;
  Serial.print("gci found \n");

  a = _pscreen->findFile(_name + ".dat");
  if (a==0x15) return 0;
  Serial.print("dat found \n");

  Serial.print("open \t");
  a = _pscreen->openTextFileDelimiter(_name+".dat", '\n');
  Serial.print(a, HEX);
  Serial.print("\n");
  if (a==0x15) return 0;

  while (_pscreen->nextTextFileDelimiter(&text)) {
    Serial.print(">");
    Serial.print(text);
    Serial.print("\n");

    // clean and split
    text = text.trim();
    splitString(text, ' ', s, 5);

    // store
    image_t _image;
    _gallery.push_back(_image);

    Serial.print("x:");
    Serial.print(stoh(s[3]), DEC);
    Serial.print(":\ty:");
    Serial.print(stoh(s[4]), DEC);
    Serial.print(":\tmsb:");
    Serial.print(stoh(s[1]), HEX);
    Serial.print(":\tlsb:");
    Serial.print(stoh(s[2]), HEX);
    Serial.print(":\n:");

    //    _image.name = s[0].substring(2, s[0].lastIndexOf('.'));
//    _gallery[_gallery.size()].msb = stoh(s[2]);
//    _gallery[_gallery.size()].lsb = stoh(s[1]);
//    _gallery[_gallery.size()].x = stoh(s[3]);
//    _gallery[_gallery.size()].y = stoh(s[4]);
        _gallery[_gallery.size()-1].msb = stoh(s[2]);
    _gallery[_gallery.size()-1].lsb = stoh(s[1]);
    _gallery[_gallery.size()-1].x = stoh(s[3]);
    _gallery[_gallery.size()-1].y = stoh(s[4]);


    //    Serial.print("available \t");
    //    Serial.print(_port->available(), DEC);
    //    Serial.print("\n");
    //
    //    Serial.print("done \t");
    //    Serial.print(done, DEC);
    //    Serial.print("\n");
  }

  //  Serial.print("available \t");
  //  Serial.print(_port->available(), DEC);
  //  Serial.print("\n");

  _index = 0;
  return _gallery.size();
}

uint8_t Gallery::number() {
  return _gallery.size();
}
uint8_t Gallery::index() {
  return _index;
}
uint8_t Gallery::showNext() {
  uint8_t a;
  a = showImage(_index);

  if (_index==_gallery.size()-1) _index=0;
  else _index++;
  
  return a;
}

uint8_t Gallery::showPrevious() {
  uint8_t a;
  a = showImage(_index);

  if (_index==0) _index=_gallery.size();
  else _index--;

  return a;
}

uint8_t Gallery::showImage(uint8_t i) {
  if ( (i<_gallery.size()) ) {

    Serial.print("\nshowImage name:");
    Serial.print(Gallery::_name);
    Serial.print(":\tx:");
    Serial.print(_gallery[i].x, DEC);
    Serial.print(":\ty:");
    Serial.print(_gallery[i].y, DEC);
    Serial.print(":\tmsb:");
    Serial.print(_gallery[i].msb, HEX);
    Serial.print(":\tlsb:");
    Serial.print(_gallery[i].lsb, HEX);
    Serial.print(":\n");

    return _pscreen->readScreenGCI(Gallery::_name+".gci", _gallery[i].x, _gallery[i].y, _gallery[i].msb, _gallery[i].lsb); 
  }
  else return 0x15;
}









